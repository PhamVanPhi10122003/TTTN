
    <section class="admin-content">
        <div class="admin-content-left">
            <ul>
                <li><a href="#">Danh mục</a>
                    <ul>
                        <li><a href="cartegoryadd.php">Thêm Danh mục</a></li>
                        <li><a href="cartegorylist.php">Danh sách Danh mục</a></li>
                    </ul>
                </li>
                <li><a href="#">Loại sản phẩm</a>
                    <ul>
                        <li><a href="brandadd.php">Thêm Loại sản phẩm</a></li>
                        <li><a href="brandlist.php">Danh Loại sản phẩm</a></li>
                    </ul>
                </li>
                <li><a href="#">Sản phẩm</a>
                    <ul>
                        <li><a href="productadd.php">Thêm Sản phẩm</a></li>
                        <li><a href="productlist.php">Danh sách sản phẩm</a></li>
                    </ul>
                </li>
                <li><a href="#">Quản lý đơn hàng</a>
                    <ul>
                        <li><a href="orderlist.php">Danh sách đơn hàng</a></li>
                    </ul>
                </li>
                <li><a href="#">Quản lý thuê sản phẩm</a>
                    <ul>
                        <li><a href="rentallist.php">Danh sách thuê sản phẩm</a></li>
                    </ul>
                </li>
                <li><a href="#">Quản lý user</a>
                    <ul>
                        <li><a href="useradd.php">Thêm user</a></li>
                        <li><a href="userlist.php">Danh sách user</a></li>
                    </ul>
                </li>
            </ul>
        </div>
        
